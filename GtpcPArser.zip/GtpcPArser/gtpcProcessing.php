<?php 
date_default_timezone_set('Asia/Dhaka');
function get_gtp_db_connection()
{
   $config = [
    'hostname' => '102.168.52.13',
    'username' => 'gtp',
    'password' => 'Gtp@1234',
    'database' => 'gtp_accounting'
  ];

  $conn = new mysqli($config['hostname'], $config['username'], $config['password'], $config['database']);
  if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
    throw $conn->connect_error;
  }
  echo "connected to db";
  return $conn;
}

#$cmd = 'tshark -i enp175s0f0 -f "udp port 2123" -T fields -e gtpv2.message_type -e gtp.message -e frame.time_epoch -e gtpv2.seq -e gtpv2.teid_c -e gtpv2.address_digits -e gtpv2.pdn_addr_and_prefix.ipv4 -e gtpv2.imsi -e gtpv2.mei -e gtpv2.uli_ecgi_eci -e gtp.seq_number -e gtp.teid_cp -e gsm_map.address.digits -e gtp.user_ipv4 -e gtp.imsi -e gtp.ext_imeisv -e gtp.lac -e gtp.apn -e gsm_a.bssmap.cell_lac -e gtp.ext_sac | awk \'$1 == "32" || $1 == "33" || $1 == "16" || $1 == "17"\' ';

$cmd = 'tshark -i enp175s0f0 -f "udp port 2123" -T fields -e gtpv2.message_type -e gtp.message -e frame.time_epoch -e gtpv2.seq -e gtpv2.address_digits -e gtpv2.pdn_addr_and_prefix.ipv4 -e gtpv2.imsi -e gtpv2.mei -e gtpv2.uli_ecgi_eci -e gtpv2.uli_tai_tac -e gtp.teid_cp -e gtp.teid -e gsm_map.address.digits -e gtp.user_ipv4 -e gtp.imsi -e gtp.ext_imeisv -e gtp.lac -e gsm_a.bssmap.cell_lac -e gtp.ext_sac | awk \'$1 == "32" || $1 == "33" || $1 == "16" || $1 == "17"\' ';

    $conn = get_gtp_db_connection();

    $a = popen($cmd, 'r');
    $tempData = []; 
    $tempData32 = [];
    $tempData33 = [];
    $tempData16 = [];
    $tempData17 = [];
    $counter = 0;
    $counter32 = 0;
    $counter33 = 0;
    $counter16 = 0;
    $counter17 = 0;
    $counterFlag = 500;
    #$myfile = fopen("/root/nergtpc/GtpcPArser/data.log", "w") or die("Unable to open file!");	
    while($b = fgets($a, 1024)) { 
        $lines = preg_replace('/\s+/'," ",trim($b));
	$cells = explode(" ",$lines);
	#echo $lines."\n";
	#fwrite($myfile, $lines."\n");
	#print_r($cells);

	
	#continue;
    
	if(trim($cells[0]) == 32)
    {
		if(count($cells) > 6)
        {
			//SESSION REQUEST
			//$messageType = trim($cells[0]);
			#$dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
            
			$dattimevalue = date("Y-m-d H:i:s", $cells[1]);
            
            $seqno  = trim($cells[2]);	
			$msisdn = trim($cells[3]);
			$ip     = trim($cells[4]);
			$imsi   = trim($cells[5]);
			$imei   = trim($cells[6]);
            
			$uli_ecgi_eci = isset($cells[7]) ? trim(dechex($cells[7])) : '';
			$uli_ecgi_eci ="0".$uli_ecgi_eci; 
			$enodeHex = substr($uli_ecgi_eci, 0, 6);
			$sac = hexdec($enodeHex);
			$cellIdHex = str_replace($enodeHex,'',$uli_ecgi_eci);
			$cellid =  hexdec($cellIdHex);
            
			$lac = isset($cells[8]) ? trim($cells[8]) : '';
			#$tempData32[] = "('32','$dattimevalue','$seqno','$msisdn','$ip','$imsi','$imei')";
			$tempData32[] = "('32','$dattimevalue','$seqno','$msisdn','$imsi','$imei','$lac','$sac','$cellid')";
			if($counter32 == $counterFlag) {
				$sql = "INSERT INTO request (msg_type , time_epoch , seq_no , msisdn , imsi , imei , lac ,sac, cellid) VALUES ";
                                batchInsert($sql, $tempData32, $conn);
                                $counter32 = 0;
                                $tempData32 = [];
			}
			$counter32++;
		}
		
	}
	if(trim($cells[0]) == 33) {
		if(count($cells) >= 4) {
                        //SESSION RESPONSE
                        //print_r($cells);
                        //$messageType = trim($cells[0]);
                        #$dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
			$dattimevalue = date("Y-m-d H:i:s", $cells[1]);
                        $seqno = trim($cells[2]);
                        $enduseraddress = trim($cells[3]);
                        #$tempData33[] = "('33','$dattimevalue','$seqno','$enduseraddress')";
			$tempData33[] = "('33','$dattimevalue','$seqno','$enduseraddress')";
                        if($counter33 == $counterFlag) {
				$sql = "INSERT INTO response  (msg_type , time_epoch , seq_no , user_ip_address) VALUES ";
                                batchInsert($sql, $tempData33, $conn);
                                $counter33 = 0;
                                $tempData33 = [];
                        }
                        $counter33++;
                }

        }
	
    if(trim($cells[0]) == 16) 
    {
		if(count($cells) > 8)
        {
            //REiQUEST
            //$messageType = trim($cells[0]);
            #$dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
			
            $dattimevalue = date("Y-m-d H:i:s", $cells[1]);
			
            $apn    = '';
            $seqno  = trim($cells[2]);
            $msisdn = trim($cells[4]);
            $imsi   = trim($cells[5]);
            $imei   = trim($cells[6]);
			$lac    = trim($cells[7]); 
			$cellid = trim($cells[8]);
			
            $sac    = isset($cells[9]) ? trim(hexdec($cells[9])) : '';
            
            //16 1631791285.205283086 0x00009b35 8801595464273 470043010772220 353416118456350 65534 wap 1901 0x00003b07
            
            $tempData16[] = "('16','$dattimevalue','$seqno','$msisdn','$imsi','$imei','$lac','$sac','$cellid')";
            if($counter16 == $counterFlag)
            {
                $sql = "INSERT INTO request (msg_type , time_epoch , seq_no , msisdn , imsi , imei , lac ,sac, cellid) VALUES ";
                batchInsert($sql, $tempData16, $conn);
                $counter16 = 0;
                $tempData16 = [];
            }
            
            $counter16++;
        }
    }
	
    if(trim($cells[0]) == 17) {
		if(count($cells) >= 4) {
                        //SESSION RESPONSE
                        #$dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
			$dattimevalue = date("Y-m-d H:i:s", $cells[1]);
                        $seqno = trim($cells[3]);
                        $enduseraddress = trim($cells[4]);
                        $tempData17[] = "('17','$dattimevalue','$seqno','$enduseraddress')";
                        if($counter17 == $counterFlag) {
                                $sql = "INSERT INTO response  (msg_type , time_epoch , seq_no , user_ip_address) VALUES ";
                                batchInsert($sql, $tempData17, $conn);
                                $counter17 = 0;
                                $tempData17 = [];
                        }
                        $counter17++;
                }

        }
	
        $tempData[] = "('$lines')";
	if($counter == $counterFlag) {
		$sql = "INSERT INTO DumpData(record) VALUES ";
        	#batchInsert($sql, $tempData, $conn);
		$counter = 0;
		$tempData = [];
	}
	$counter++;
	
        #ob_flush();
	flush(); 
    }

    pclose($a); 

function batchInsert($sql = '', $data = array(), $conn = '') {
        if (!empty($sql) && !empty($data) && !empty($conn)) {
            $records = array_chunk($data, 500, true);
            foreach ($records as $rows) {
                $query = $sql . implode(', ', $rows) . ';';
                #echo "update query = {$query} \n";
                $update_result = $conn->query($query) or print (mysqli_error($conn)); //or die(mysql_error());

            }
        }
    }


?>
