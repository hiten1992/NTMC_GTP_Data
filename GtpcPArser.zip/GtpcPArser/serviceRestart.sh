#!/bin/bash
/bin/systemctl restart gtpcParsing.service
