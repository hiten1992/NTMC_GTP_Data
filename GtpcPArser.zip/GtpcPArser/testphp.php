<?php
date_default_timezone_set('Asia/Dhaka');
echo $dattimevalue = date("Y-m-d H:i:s", '1632224020.859991123');
exit;

/*
#$cmd = 'tshark -i enp175s0f0 -f "udp port 2123" -T fields -e gtpv2.message_type -e gtp.message -e frame.time_epoch -e gtpv2.seq -e gtpv2.address_digits -e gtpv2.pdn_addr_and_prefix.ipv4 -e gtpv2.imsi -e gtpv2.mei -e gtpv2.uli_ecgi_eci -e gtp.seq_number -e gsm_map.address.digits -e gtp.user_ipv4 -e gtp.imsi -e gtp.lac -e gtp.apn -e gsm_a.bssmap.cell_lac -e gtp.ext_sac -e gtp.ext_imeisv | awk \'$1 == "32" || $1 == "33" || $1 == "16" || $1 == "17"  { print $1, $2, $3, $4, $5, $6, $7, $8, $9 }\'';

$cmd = 'tshark -i enp175s0f0 -f "udp port 2123" -T fields -e gtpv2.message_type -e gtp.message -e frame.time_epoch -e gtpv2.seq -e gtpv2.address_digits -e gtpv2.pdn_addr_and_prefix.ipv4 -e gtpv2.imsi -e gtpv2.mei -e gtpv2.uli_ecgi_eci -e gtp.seq_number -e gsm_map.address.digits -e gtp.user_ipv4 -e gtp.imsi -e gtp.lac -e gtp.apn -e gsm_a.bssmap.cell_lac -e gtp.ext_sac -e gtp.ext_imeisv | awk \'$1 == "32" || $1 == "33" || $1 == "16" || $1 == "17"\'';

$output = passthru($cmd);


if(!empty($output)) {

	$cells = explode(" ",$output);

	if(!empty($cells)) {
echo "khiro";
		print_r($cells);

	}

}

*/

$cmd = 'tshark -i enp175s0f0 -f "udp port 2123" -T fields -e gtpv2.message_type -e gtp.message -e frame.time_epoch -e gtpv2.seq -e gtpv2.address_digits -e gtpv2.pdn_addr_and_prefix.ipv4 -e gtpv2.imsi -e gtpv2.mei -e gtpv2.uli_ecgi_eci -e gtp.seq_number -e gsm_map.address.digits -e gtp.user_ipv4 -e gtp.imsi -e gtp.lac -e gtp.apn -e gsm_a.bssmap.cell_lac -e gtp.ext_sac -e gtp.ext_imeisv | awk \'$1 == "32" || $1 == "33" || $1 == "16" || $1 == "17"\'';

while(system($cmd)) {
	echo $lines;
}

?>
