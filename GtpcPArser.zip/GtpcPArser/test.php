<?php 

function get_gtp_db_connection()
{
  $config = [
    'hostname' => 'localhost',
    'username' => 'root',
    'password' => 'Passw0rd',
    'database' => 'mydb_hiten'
  ];

  $conn = new mysqli($config['hostname'], $config['username'], $config['password'], $config['database']);
  if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
    throw $conn->connect_error;
  }
  echo "connected to db";
  return $conn;
}

#$cmd = "ping 127.0.0.1";
$cmd = 'tshark -i enp175s0f0 -f "udp port 2123" -T fields -e gtpv2.message_type -e gtp.message -e frame.time_epoch -e gtpv2.seq -e gtpv2.address_digits -e gtpv2.pdn_addr_and_prefix.ipv4 -e gtpv2.imsi -e gtpv2.mei -e gtpv2.uli_ecgi_eci -e gtp.seq_number -e gsm_map.address.digits -e gtp.user_ipv4 -e gtp.imsi -e gtp.ext_imeisv -e gtp.lac -e gtp.apn -e gsm_a.bssmap.cell_lac -e gtp.ext_sac | awk \'$1 == "32" || $1 == "33" || $1 == "16" || $1 == "17"\'';

    $conn = get_gtp_db_connection();

    $a = popen($cmd, 'r');
    $tempData = []; 
    $tempData32 = [];
    $tempData33 = [];
    $tempData16 = [];
    $tempData17 = [];
    $counter = 0;
    $counter32 = 0;
    $counter33 = 0;
    $counter16 = 0;
    $counter17 = 0;	
    while($b = fgets($a, 2048)) { 
        $lines = preg_replace('/\s+/'," ",trim($b));
	$cells = explode(" ",$lines);
	echo $lines."\n";
	if(trim($cells[0]) == 32) {
		if(count($cells) > 6) {
			//SESSION REQUEST
			//$messageType = trim($cells[0]);
			$dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
		        $seqno = trim($cells[2]);	
			$msisdn = trim($cells[3]);
			$ip = trim($cells[4]);
			$imsi = trim($cells[5]);
			$imei = trim($cells[6]);
			$tempData32[] = "('32','$dattimevalue','$seqno','$msisdn','$ip','$imsi','$imei')";
			if($counter32 == 1000) {
				$sql = "INSERT INTO session_request (MsgType , TIME_EPOCH , SEQ_NO , MSISDN , GSN_IP1 , IMSI , IMEI) VALUES ";
				batchInsert($sql, $tempData32, $conn);
				$counter32 = 0;
				$tempData32 = [];
			}
			$counter32++;
		}
		
	}
	if(trim($cells[0]) == 33) {
		if(count($cells) == 4) {
                        //SESSION RESPONSE
                        //print_r($cells);
                        //$messageType = trim($cells[0]);
                        $dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
                        $seqno = trim($cells[2]);
                        $enduseraddress = trim($cells[3]);
                        $tempData33[] = "('33','$dattimevalue','$seqno','$enduseraddress')";
                        if($counter33 == 1000) {
                                $sql = "INSERT INTO session_response  (MsgType , TIME_EPOCH , SEQ_NO , End_user_addr) VALUES ";
                                batchInsert($sql, $tempData33, $conn);
                                $counter33 = 0;
                                $tempData33 = [];
                        }
                        $counter33++;
                }

        }
	if(trim($cells[0]) == 16) {
		if(count($cells) > 8) {
                        //REiQUEST
                        //$messageType = trim($cells[0]);
                        $dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
                        $seqno = trim($cells[2]);
                        $msisdn = trim($cells[3]);
                        $imsi = trim($cells[4]);
                        $imei = trim($cells[5]);
			$cgilac = trim($cells[6]); 
			$apn    = trim($cells[7]);
			$cgicellid = trim($cells[8]);
                        $tempData16[] = "('16','$dattimevalue','$seqno','$msisdn','$imsi','$imei','$cgilac','$apn','$cgicellid')";
                        if($counter16 == 1000) {
                                $sql = "INSERT INTO request (MsgType , TIME_EPOCH , SEQ_NO , MSISDN , IMSI , IMEI , CGI_LAC , APN , CGI_Cell_ID) VALUES ";
                                batchInsert($sql, $tempData16, $conn);
                                $counter16 = 0;
                                $tempData16 = [];
                        }
                        $counter16++;
                }

        }
	if(trim($cells[0]) == 17) {
		if(count($cells) == 4) {
                        //SESSION RESPONSE
                        $dattimevalue = date("Y-m-d H:i:s", substr($cells[1], 0, 10));
                        $seqno = trim($cells[2]);
                        $enduseraddress = trim($cells[3]);
                        $tempData17[] = "('17','$dattimevalue','$seqno','$enduseraddress')";
                        if($counter17 == 1000) {
                                $sql = "INSERT INTO response  (MsgType , TIME_EPOCH , SEQ_NO , End_user_addr) VALUES ";
                                batchInsert($sql, $tempData17, $conn);
                                $counter17 = 0;
                                $tempData17 = [];
                        }
                        $counter17++;
                }

        }
	
        $tempData[] = "('$lines')";
	if($counter == 1000) {
		$sql = "INSERT INTO DumpData(record) VALUES ";
        	batchInsert($sql, $tempData, $conn);
		$counter = 0;
		$tempData = [];
	}
	$counter++;
	
        #ob_flush();flush(); 
    }

    pclose($a); 

function batchInsert($sql = '', $data = array(), $conn = '') {
        if (!empty($sql) && !empty($data) && !empty($conn)) {
            $records = array_chunk($data, 500, true);
            foreach ($records as $rows) {
                $query = $sql . implode(', ', $rows) . ';';
                #echo "update query = {$query} \n";
                $update_result = $conn->query($query) or die(mysql_error());

            }
        }
    }


?>
