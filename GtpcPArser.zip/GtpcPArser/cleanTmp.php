<?php 
$time = 30; //in minutes, time until file deletion threshold
foreach (glob("/tmp/wireshark_pcapng_enp175s0f0*") as $filename) {
	echo $filename."\n";
    if (file_exists($filename)) {
        if(time() - filemtime($filename) > $time * 60) {
            unlink($filename);
        }
    }
}

if(`service gtpcParsing status | grep running`) {
	echo "RUNNIG";
}
else {
	echo "not running";
	`service gtpcParsing start`;
}

?>
